import React, { useState, useEffect } from 'react';
import analyticsApi from '../../../api/analytics';
import Icon from '../../../components/AppIcon';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from 'recharts';

const PsychologyTab = ({ selectedAccount }) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [psychology, setPsychology] = useState(null);

  useEffect(() => {
    fetchPsychology();
  }, [selectedAccount]);

  const fetchPsychology = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await analyticsApi?.getPsychology();
      setPsychology(data);
    } catch (err) {
      setError(err?.response?.data?.message || 'Failed to load psychology data');
    } finally {
      setLoading(false);
    }
  };

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];

  if (error) {
    return (
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <Icon name="AlertCircle" size={48} className="mx-auto mb-4 text-destructive" />
        <h3 className="text-lg font-semibold text-foreground mb-2">Error Loading Data</h3>
        <p className="text-muted-foreground mb-4">{error}</p>
        <button
          onClick={fetchPsychology}
          className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90 transition-colors"
        >
          <Icon name="RefreshCw" size={16} />
          Retry
        </button>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="h-64 bg-muted rounded animate-pulse"></div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {[1, 2]?.map((i) => (
            <div key={i} className="bg-card border border-border rounded-lg p-6 animate-pulse">
              <div className="h-6 bg-muted rounded w-1/2 mb-4"></div>
              <div className="h-4 bg-muted rounded w-full"></div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (!psychology) {
    return (
      <div className="bg-card border border-border rounded-lg p-8 text-center">
        <Icon name="Brain" size={48} className="mx-auto mb-4 text-muted-foreground" />
        <h3 className="text-lg font-semibold text-foreground mb-2">No Psychology Data</h3>
        <p className="text-muted-foreground">No psychological trading data recorded yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {psychology?.emotionDistribution && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Emotion Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={psychology?.emotionDistribution}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name}: ${(percent * 100)?.toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {psychology?.emotionDistribution?.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS?.[index % COLORS?.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-success/10 flex items-center justify-center">
              <Icon name="Smile" size={20} className="text-success" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Positive Emotions</h3>
          </div>
          <div className="space-y-3">
            {psychology?.positiveEmotions?.map((emotion, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">{emotion?.name}</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-success rounded-full"
                      style={{ width: `${emotion?.percentage}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-semibold text-foreground w-12 text-right">{emotion?.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-lg bg-destructive/10 flex items-center justify-center">
              <Icon name="Frown" size={20} className="text-destructive" />
            </div>
            <h3 className="text-lg font-semibold text-foreground">Negative Emotions</h3>
          </div>
          <div className="space-y-3">
            {psychology?.negativeEmotions?.map((emotion, index) => (
              <div key={index} className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">{emotion?.name}</span>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-destructive rounded-full"
                      style={{ width: `${emotion?.percentage}%` }}
                    ></div>
                  </div>
                  <span className="text-sm font-semibold text-foreground w-12 text-right">{emotion?.percentage}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      {psychology?.insights && (
        <div className="bg-card border border-border rounded-lg p-6">
          <h3 className="text-lg font-semibold text-foreground mb-4">Psychological Insights</h3>
          <ul className="space-y-2">
            {psychology?.insights?.map((insight, index) => (
              <li key={index} className="flex items-start gap-2">
                <Icon name="CheckCircle" size={16} className="text-primary mt-0.5" />
                <span className="text-sm text-muted-foreground">{insight}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default PsychologyTab;