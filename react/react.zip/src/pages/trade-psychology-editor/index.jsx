import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AuthenticatedHeader from '../../components/layout/AuthenticatedHeader';
import PrimaryNavigation from '../../components/layout/PrimaryNavigation';
import AccountContextBar from '../../components/layout/AccountContextBar';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';
import EmotionTagSelector from './components/EmotionTagSelector';
import DecisionQualityRating from './components/DecisionQualityRating';
import MarketConditionAssessment from './components/MarketConditionAssessment';
import TradeReferencePanel from './components/TradeReferencePanel';
import TemplatePrompts from './components/TemplatePrompts';
import RichTextEditor from './components/RichTextEditor';
import SearchFilterPanel from './components/SearchFilterPanel';

const TradePsychologyEditor = () => {
  const navigate = useNavigate();
  const [selectedAccount, setSelectedAccount] = useState('');
  const [activeView, setActiveView] = useState('editor');
  const [autoSaveStatus, setAutoSaveStatus] = useState('saved');
  const [lastSaved, setLastSaved] = useState(new Date());

  const [psychologyEntry, setPsychologyEntry] = useState({
    tradeId: 'TRD-2026-001',
    emotions: [],
    decisionQuality: 0,
    marketCondition: '',
    volatility: '',
    preTradeMindset: '',
    decisionProcess: '',
    executionExperience: '',
    whatWentWell: '',
    areasForImprovement: '',
    keyLessons: ''
  });

  const [searchFilters, setSearchFilters] = useState({
    searchQuery: '',
    dateRange: 'all',
    emotionFilter: 'all'
  });

  const mockTradeData = {
    symbol: 'AAPL',
    direction: 'Long',
    entryPrice: 178.50,
    exitPrice: 182.30,
    quantity: 100,
    profitLoss: 380.00,
    returnPercentage: 2.13,
    entryTime: '2026-01-14T09:30:00',
    exitTime: '2026-01-14T14:45:00'
  };

  const mockPreviousEntries = [
    {
      id: 'PSY-001',
      tradeId: 'TRD-2026-001',
      symbol: 'AAPL',
      date: '2026-01-14',
      emotions: ['confidence', 'calm'],
      decisionQuality: 4,
      profitLoss: 380.00,
      preview: 'Entered with clear plan and proper risk management. Market conditions were favorable with low volatility...'
    },
    {
      id: 'PSY-002',
      tradeId: 'TRD-2026-002',
      symbol: 'TSLA',
      date: '2026-01-13',
      emotions: ['fear', 'uncertainty'],
      decisionQuality: 2,
      profitLoss: -245.00,
      preview: 'Hesitated on entry, second-guessed the setup. Should have trusted the analysis and followed the plan...'
    },
    {
      id: 'PSY-003',
      tradeId: 'TRD-2026-003',
      symbol: 'MSFT',
      date: '2026-01-12',
      emotions: ['greed', 'excitement'],
      decisionQuality: 3,
      profitLoss: 520.00,
      preview: 'Held position too long hoping for bigger gains. Profit target was hit but greed prevented exit...'
    }
  ];

  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      if (autoSaveStatus === 'saving') return;
      
      setAutoSaveStatus('saving');
      setTimeout(() => {
        setAutoSaveStatus('saved');
        setLastSaved(new Date());
      }, 1000);
    }, 30000);

    return () => clearInterval(autoSaveInterval);
  }, [autoSaveStatus]);

  const handleEmotionToggle = (emotionId) => {
    setPsychologyEntry(prev => ({
      ...prev,
      emotions: prev?.emotions?.includes(emotionId)
        ? prev?.emotions?.filter(e => e !== emotionId)
        : [...prev?.emotions, emotionId]
    }));
    setAutoSaveStatus('unsaved');
  };

  const handleRatingChange = (rating) => {
    setPsychologyEntry(prev => ({ ...prev, decisionQuality: rating }));
    setAutoSaveStatus('unsaved');
  };

  const handleFieldChange = (field, value) => {
    setPsychologyEntry(prev => ({ ...prev, [field]: value }));
    setAutoSaveStatus('unsaved');
  };

  const handleTemplateSelect = (template) => {
    const templateContent = template?.sections?.map(section => 
      `### ${section?.title}\n\n${section?.prompt}\n\n`
    )?.join('\n');

    setPsychologyEntry(prev => ({
      ...prev,
      preTradeMindset: templateContent
    }));
    setAutoSaveStatus('unsaved');
  };

  const handleSave = () => {
    setAutoSaveStatus('saving');
    setTimeout(() => {
      setAutoSaveStatus('saved');
      setLastSaved(new Date());
    }, 1000);
  };

  const handlePublish = () => {
    setAutoSaveStatus('saving');
    setTimeout(() => {
      setAutoSaveStatus('saved');
      setLastSaved(new Date());
      navigate('/trades-management');
    }, 1000);
  };

  const formatLastSaved = () => {
    const now = new Date();
    const diff = Math.floor((now - lastSaved) / 1000);
    
    if (diff < 60) return 'Just now';
    if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
    return lastSaved?.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const getAutoSaveIcon = () => {
    switch (autoSaveStatus) {
      case 'saving': return 'Loader';
      case 'saved': return 'Check';
      default: return 'AlertCircle';
    }
  };

  const getAutoSaveColor = () => {
    switch (autoSaveStatus) {
      case 'saving': return 'text-warning';
      case 'saved': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader />
      <PrimaryNavigation />
      <AccountContextBar onAccountChange={setSelectedAccount} />
      <main className="main-content with-account-context">
        <div className="main-content-container">
          <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 mb-6 md:mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-2">
                Trade Psychology Editor
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Document and analyze the psychological aspects of your trading decisions
              </p>
            </div>

            <div className="flex items-center gap-3 w-full lg:w-auto">
              <div className={`flex items-center gap-2 text-xs md:text-sm ${getAutoSaveColor()}`}>
                <Icon 
                  name={getAutoSaveIcon()} 
                  size={16} 
                  className={autoSaveStatus === 'saving' ? 'animate-spin' : ''} 
                />
                <span>
                  {autoSaveStatus === 'saved' ? `Saved ${formatLastSaved()}` : 
                   autoSaveStatus === 'saving' ? 'Saving...' : 'Unsaved changes'}
                </span>
              </div>
              <Button
                variant="outline"
                size="default"
                onClick={handleSave}
                iconName="Save"
                iconPosition="left"
                disabled={autoSaveStatus === 'saving'}
                className="flex-1 lg:flex-initial"
              >
                Save Draft
              </Button>
              <Button
                variant="default"
                size="default"
                onClick={handlePublish}
                iconName="Send"
                iconPosition="left"
                disabled={autoSaveStatus === 'saving'}
                className="flex-1 lg:flex-initial"
              >
                Publish
              </Button>
            </div>
          </div>

          <div className="flex gap-2 mb-6 border-b border-border">
            <button
              onClick={() => setActiveView('editor')}
              className={`px-4 md:px-6 py-3 text-sm md:text-base font-medium transition-all duration-250 border-b-2 ${
                activeView === 'editor' ?'text-primary border-primary' :'text-muted-foreground border-transparent hover:text-foreground'
              }`}
            >
              <Icon name="Edit" size={18} className="inline mr-2" />
              Editor
            </button>
            <button
              onClick={() => setActiveView('history')}
              className={`px-4 md:px-6 py-3 text-sm md:text-base font-medium transition-all duration-250 border-b-2 ${
                activeView === 'history' ?'text-primary border-primary' :'text-muted-foreground border-transparent hover:text-foreground'
              }`}
            >
              <Icon name="History" size={18} className="inline mr-2" />
              History
            </button>
          </div>

          {activeView === 'editor' ? (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8">
              <div className="lg:col-span-2 space-y-6 md:space-y-8">
                <div className="bg-card border border-border rounded-lg p-4 md:p-6 space-y-6">
                  <EmotionTagSelector
                    selectedEmotions={psychologyEntry?.emotions}
                    onEmotionToggle={handleEmotionToggle}
                  />

                  <DecisionQualityRating
                    rating={psychologyEntry?.decisionQuality}
                    onRatingChange={handleRatingChange}
                  />

                  <MarketConditionAssessment
                    marketCondition={psychologyEntry?.marketCondition}
                    onConditionChange={(value) => handleFieldChange('marketCondition', value)}
                    volatility={psychologyEntry?.volatility}
                    onVolatilityChange={(value) => handleFieldChange('volatility', value)}
                  />
                </div>

                <TemplatePrompts onTemplateSelect={handleTemplateSelect} />

                <div className="bg-card border border-border rounded-lg p-4 md:p-6 space-y-6">
                  <RichTextEditor
                    label="Pre-Trade Mindset"
                    value={psychologyEntry?.preTradeMindset}
                    onChange={(value) => handleFieldChange('preTradeMindset', value)}
                    placeholder="Describe your mental state and thought process before entering the trade..."
                  />

                  <RichTextEditor
                    label="Decision Process"
                    value={psychologyEntry?.decisionProcess}
                    onChange={(value) => handleFieldChange('decisionProcess', value)}
                    placeholder="What factors influenced your decision? Did you follow your trading plan?"
                  />

                  <RichTextEditor
                    label="Execution Experience"
                    value={psychologyEntry?.executionExperience}
                    onChange={(value) => handleFieldChange('executionExperience', value)}
                    placeholder="How did you feel during trade execution? Any emotional challenges?"
                  />

                  <RichTextEditor
                    label="What Went Well"
                    value={psychologyEntry?.whatWentWell}
                    onChange={(value) => handleFieldChange('whatWentWell', value)}
                    placeholder="Identify positive aspects of your trading psychology and discipline..."
                  />

                  <RichTextEditor
                    label="Areas for Improvement"
                    value={psychologyEntry?.areasForImprovement}
                    onChange={(value) => handleFieldChange('areasForImprovement', value)}
                    placeholder="What could you have done differently? What mistakes were made?"
                  />

                  <RichTextEditor
                    label="Key Lessons Learned"
                    value={psychologyEntry?.keyLessons}
                    onChange={(value) => handleFieldChange('keyLessons', value)}
                    placeholder="What specific insights can you apply to future trades?"
                  />
                </div>
              </div>

              <div className="space-y-6">
                <TradeReferencePanel tradeData={mockTradeData} />

                <div className="bg-card border border-border rounded-lg p-4 md:p-6">
                  <h3 className="text-base md:text-lg font-semibold text-foreground mb-4">Quick Tips</h3>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <Icon name="Lightbulb" size={18} className="text-warning flex-shrink-0 mt-0.5" />
                      <p className="text-xs md:text-sm text-muted-foreground">
                        Be honest about emotions - this journal is for your improvement
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Icon name="Target" size={18} className="text-success flex-shrink-0 mt-0.5" />
                      <p className="text-xs md:text-sm text-muted-foreground">
                        Focus on process over outcome - good decisions can have bad results
                      </p>
                    </div>
                    <div className="flex items-start gap-3">
                      <Icon name="TrendingUp" size={18} className="text-primary flex-shrink-0 mt-0.5" />
                      <p className="text-xs md:text-sm text-muted-foreground">
                        Review entries regularly to identify patterns and improve
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-6">
              <SearchFilterPanel
                searchQuery={searchFilters?.searchQuery}
                onSearchChange={(value) => setSearchFilters(prev => ({ ...prev, searchQuery: value }))}
                dateRange={searchFilters?.dateRange}
                onDateRangeChange={(value) => setSearchFilters(prev => ({ ...prev, dateRange: value }))}
                emotionFilter={searchFilters?.emotionFilter}
                onEmotionFilterChange={(value) => setSearchFilters(prev => ({ ...prev, emotionFilter: value }))}
                onClearFilters={() => setSearchFilters({ searchQuery: '', dateRange: 'all', emotionFilter: 'all' })}
              />

              <div className="grid grid-cols-1 gap-4 md:gap-6">
                {mockPreviousEntries?.map((entry) => (
                  <div
                    key={entry?.id}
                    className="bg-card border border-border rounded-lg p-4 md:p-6 hover:border-accent/50 transition-all duration-250 cursor-pointer"
                    onClick={() => setActiveView('editor')}
                  >
                    <div className="flex flex-col md:flex-row md:items-start justify-between gap-4 mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-base md:text-lg font-semibold text-foreground">{entry?.symbol}</h3>
                          <span className="text-xs md:text-sm text-muted-foreground">{entry?.tradeId}</span>
                          <span className={`text-sm md:text-base font-semibold ${entry?.profitLoss >= 0 ? 'text-success' : 'text-error'}`}>
                            {entry?.profitLoss >= 0 ? '+' : ''}${Math.abs(entry?.profitLoss)?.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-xs md:text-sm text-muted-foreground">
                          {new Date(entry.date)?.toLocaleDateString('en-US', { 
                            month: 'long', 
                            day: 'numeric', 
                            year: 'numeric' 
                          })}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        {entry?.emotions?.map((emotion) => (
                          <span
                            key={emotion}
                            className="px-2 md:px-3 py-1 text-xs rounded-full bg-accent/10 text-accent capitalize"
                          >
                            {emotion}
                          </span>
                        ))}
                      </div>
                    </div>

                    <p className="text-sm md:text-base text-muted-foreground line-clamp-2 mb-4">
                      {entry?.preview}
                    </p>

                    <div className="flex items-center justify-between pt-4 border-t border-border">
                      <div className="flex items-center gap-2">
                        <span className="text-xs md:text-sm text-muted-foreground">Decision Quality:</span>
                        <div className="flex items-center gap-1">
                          {[1, 2, 3, 4, 5]?.map((star) => (
                            <Icon
                              key={star}
                              name={star <= entry?.decisionQuality ? 'Star' : 'Star'}
                              size={16}
                              className={star <= entry?.decisionQuality ? 'text-warning fill-warning' : 'text-muted-foreground'}
                            />
                          ))}
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" iconName="ChevronRight">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default TradePsychologyEditor;