import React from 'react';
import Icon from '../../../components/AppIcon';

const EmotionTagSelector = ({ selectedEmotions, onEmotionToggle }) => {
  const emotionTags = [
    { id: 'fear', label: 'Fear', icon: 'AlertTriangle', color: 'text-red-600', bgColor: 'bg-red-50', borderColor: 'border-red-200' },
    { id: 'greed', label: 'Greed', icon: 'TrendingUp', color: 'text-orange-600', bgColor: 'bg-orange-50', borderColor: 'border-orange-200' },
    { id: 'confidence', label: 'Confidence', icon: 'Award', color: 'text-green-600', bgColor: 'bg-green-50', borderColor: 'border-green-200' },
    { id: 'uncertainty', label: 'Uncertainty', icon: 'HelpCircle', color: 'text-yellow-600', bgColor: 'bg-yellow-50', borderColor: 'border-yellow-200' },
    { id: 'excitement', label: 'Excitement', icon: 'Zap', color: 'text-purple-600', bgColor: 'bg-purple-50', borderColor: 'border-purple-200' },
    { id: 'frustration', label: 'Frustration', icon: 'Frown', color: 'text-red-500', bgColor: 'bg-red-50', borderColor: 'border-red-200' },
    { id: 'calm', label: 'Calm', icon: 'Smile', color: 'text-blue-600', bgColor: 'bg-blue-50', borderColor: 'border-blue-200' },
    { id: 'anxiety', label: 'Anxiety', icon: 'AlertCircle', color: 'text-amber-600', bgColor: 'bg-amber-50', borderColor: 'border-amber-200' }
  ];

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-foreground">
        Emotional State
      </label>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2 md:gap-3">
        {emotionTags?.map((emotion) => {
          const isSelected = selectedEmotions?.includes(emotion?.id);
          return (
            <button
              key={emotion?.id}
              type="button"
              onClick={() => onEmotionToggle(emotion?.id)}
              className={`flex items-center gap-2 px-3 md:px-4 py-2 md:py-3 rounded-lg border-2 transition-all duration-250 ${
                isSelected
                  ? `${emotion?.bgColor} ${emotion?.borderColor} ${emotion?.color}`
                  : 'bg-card border-border text-muted-foreground hover:border-accent/30'
              }`}
              aria-pressed={isSelected}
            >
              <Icon name={emotion?.icon} size={18} className="flex-shrink-0" />
              <span className="text-xs md:text-sm font-medium truncate">{emotion?.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default EmotionTagSelector;