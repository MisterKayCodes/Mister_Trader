import React from 'react';
import Icon from '../../../components/AppIcon';

const DecisionQualityRating = ({ rating, onRatingChange }) => {
  const ratingLevels = [
    { value: 1, label: 'Poor', color: 'text-red-600', bgColor: 'bg-red-50', icon: 'ThumbsDown' },
    { value: 2, label: 'Below Average', color: 'text-orange-600', bgColor: 'bg-orange-50', icon: 'TrendingDown' },
    { value: 3, label: 'Average', color: 'text-yellow-600', bgColor: 'bg-yellow-50', icon: 'Minus' },
    { value: 4, label: 'Good', color: 'text-green-600', bgColor: 'bg-green-50', icon: 'TrendingUp' },
    { value: 5, label: 'Excellent', color: 'text-emerald-600', bgColor: 'bg-emerald-50', icon: 'ThumbsUp' }
  ];

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-foreground">
        Decision Quality Rating
      </label>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-2 md:gap-3">
        {ratingLevels?.map((level) => {
          const isSelected = rating === level?.value;
          return (
            <button
              key={level?.value}
              type="button"
              onClick={() => onRatingChange(level?.value)}
              className={`flex flex-col items-center gap-2 px-3 md:px-4 py-3 md:py-4 rounded-lg border-2 transition-all duration-250 ${
                isSelected
                  ? `${level?.bgColor} border-current ${level?.color}`
                  : 'bg-card border-border text-muted-foreground hover:border-accent/30'
              }`}
              aria-pressed={isSelected}
            >
              <Icon name={level?.icon} size={24} />
              <span className="text-xs md:text-sm font-medium text-center">{level?.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default DecisionQualityRating;