import React from 'react';
import Icon from '../../../components/AppIcon';

const TradeReferencePanel = ({ tradeData }) => {
  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    })?.format(value);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const profitLossColor = tradeData?.profitLoss >= 0 ? 'text-success' : 'text-error';
  const profitLossIcon = tradeData?.profitLoss >= 0 ? 'TrendingUp' : 'TrendingDown';

  return (
    <div className="bg-card border border-border rounded-lg p-4 md:p-6 space-y-4 md:space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-base md:text-lg font-semibold text-foreground">Trade Reference</h3>
        <span className={`flex items-center gap-1 text-sm md:text-base font-semibold ${profitLossColor}`}>
          <Icon name={profitLossIcon} size={18} />
          {formatCurrency(tradeData?.profitLoss)}
        </span>
      </div>
      <div className="space-y-3 md:space-y-4">
        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Symbol</span>
          <span className="text-sm md:text-base font-medium text-foreground">{tradeData?.symbol}</span>
        </div>

        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Direction</span>
          <span className={`text-sm md:text-base font-medium ${tradeData?.direction === 'Long' ? 'text-success' : 'text-error'}`}>
            {tradeData?.direction}
          </span>
        </div>

        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Entry Price</span>
          <span className="text-sm md:text-base font-medium text-foreground">{formatCurrency(tradeData?.entryPrice)}</span>
        </div>

        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Exit Price</span>
          <span className="text-sm md:text-base font-medium text-foreground">{formatCurrency(tradeData?.exitPrice)}</span>
        </div>

        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Quantity</span>
          <span className="text-sm md:text-base font-medium text-foreground">{tradeData?.quantity}</span>
        </div>

        <div className="flex items-center justify-between py-2 border-b border-border">
          <span className="text-xs md:text-sm text-muted-foreground">Entry Time</span>
          <span className="text-xs md:text-sm text-foreground">{formatDate(tradeData?.entryTime)}</span>
        </div>

        <div className="flex items-center justify-between py-2">
          <span className="text-xs md:text-sm text-muted-foreground">Exit Time</span>
          <span className="text-xs md:text-sm text-foreground">{formatDate(tradeData?.exitTime)}</span>
        </div>
      </div>
      <div className="pt-3 md:pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-xs md:text-sm font-medium text-muted-foreground">Return %</span>
          <span className={`text-base md:text-lg font-semibold ${profitLossColor}`}>
            {tradeData?.returnPercentage > 0 ? '+' : ''}{tradeData?.returnPercentage?.toFixed(2)}%
          </span>
        </div>
      </div>
    </div>
  );
};

export default TradeReferencePanel;