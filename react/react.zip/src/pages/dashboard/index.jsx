import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import api from '../../auth/api'; // axios instance with auth

import AuthenticatedHeader from '../../components/layout/AuthenticatedHeader';
import PrimaryNavigation from '../../components/layout/PrimaryNavigation';
import AccountContextBar from '../../components/layout/AccountContextBar';
import MetricCard from './components/MetricCard';
import RecentTradesTable from './components/RecentTradesTable';
import PerformanceChart from './components/PerformanceChart';
import QuickActions from './components/QuickActions';
import TradingInsights from './components/TradingInsights';

const Dashboard = () => {
  const navigate = useNavigate();
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [loading, setLoading] = useState(false);
  const [metrics, setMetrics] = useState({
    totalProfitLoss: 0,
    winRate: 0,
    avgTradeDuration: '',
    activePositions: 0
  });
  const [recentTrades, setRecentTrades] = useState([]);
  const [performanceData, setPerformanceData] = useState([]);
  const [insights, setInsights] = useState([]);

  useEffect(() => {
    if (selectedAccount) {
      fetchDashboardData(selectedAccount);
    }
  }, [selectedAccount]);

  const fetchDashboardData = async (accountId) => {
    setLoading(true);

    try {
      // Fetch analytics stats
      const statsRes = await api.get('/analytics/stats', {
        params: { account_id: accountId }
      });
      const stats = statsRes.data;

      // Fetch recent trades (limit to 5 most recent)
      const tradesRes = await api.get('/trades', {
        params: { account_id: accountId }
      });
      const trades = tradesRes.data;
      const recent = trades.slice(-5).reverse();

      // You might want to create an endpoint for performance data if it exists,
      // or derive it from trades, here just dummy empty for now
      const performanceRes = await api.get('/analytics/hourly', {
        params: { account_id: accountId }
      });
      const performance = performanceRes.data.hourly || [];

      // Fetch trading psychology insights
      const psychologyRes = await api.get('/analytics/psychology', {
        params: { account_id: accountId }
      });
      const psychology = psychologyRes.data || [];

      // Calculate avg trade duration from trades if you want
      const avgDuration = calculateAvgTradeDuration(trades);

      // Calculate active positions - trades with state != closed
      const activePositionsCount = trades.filter(t => t.state !== 'closed').length;

      setMetrics({
        totalProfitLoss: stats.total_pnl || 0,
        winRate: stats.win_rate || 0,
        avgTradeDuration: avgDuration,
        activePositions: activePositionsCount
      });

      setRecentTrades(recent);
      setPerformanceData(performance);
      setInsights(psychology);
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      // optionally set error state here
    }

    setLoading(false);
  };

  const calculateAvgTradeDuration = (trades) => {
    if (!trades.length) return '';
    // Example: average difference between open_timestamp and close_timestamp in days
    const closedTrades = trades.filter(t => t.state === 'closed' && t.open_timestamp && t.close_timestamp);
    if (!closedTrades.length) return '';

    const totalMs = closedTrades.reduce((acc, t) => {
      const openDate = new Date(t.open_timestamp);
      const closeDate = new Date(t.close_timestamp);
      return acc + (closeDate - openDate);
    }, 0);

    const avgMs = totalMs / closedTrades.length;
    const avgDays = avgMs / (1000 * 60 * 60 * 24);
    return `${avgDays.toFixed(1)} days`;
  };

  const handleAccountChange = (accountId) => {
    setSelectedAccount(accountId);
  };

  const handleViewAllTrades = () => {
    navigate('/trades-management');
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    }).format(value);
  };

  return (
    <div className="min-h-screen bg-background">
      <AuthenticatedHeader />
      <PrimaryNavigation />
      <AccountContextBar onAccountChange={handleAccountChange} />
      <main className="main-content with-account-context">
        <div className="main-content-container">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-2">
              Trading Dashboard
            </h1>
            <p className="text-sm md:text-base text-muted-foreground">
              Monitor your trading performance and key metrics
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
            <MetricCard
              title="Total P/L"
              value={formatCurrency(metrics?.totalProfitLoss)}
              change="+12.4% this month" // Ideally get real change data from backend
              changeType="positive"
              icon="DollarSign"
              iconColor="var(--color-success)"
              loading={loading}
            />
            <MetricCard
              title="Win Rate"
              value={`${metrics?.winRate.toFixed(1)}%`}
              change="+3.2% vs last month"
              changeType="positive"
              icon="Target"
              iconColor="var(--color-primary)"
              loading={loading}
            />
            <MetricCard
              title="Avg Trade Duration"
              value={metrics?.avgTradeDuration}
              change="-0.3 days vs avg"
              changeType="neutral"
              icon="Clock"
              iconColor="var(--color-accent)"
              loading={loading}
            />
            <MetricCard
              title="Active Positions"
              value={metrics?.activePositions}
              change="—" // Add real data if available
              changeType="neutral"
              icon="TrendingUp"
              iconColor="var(--color-warning)"
              loading={loading}
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
            <div className="lg:col-span-2">
              <PerformanceChart data={performanceData} loading={loading} />
            </div>
            <div>
              <TradingInsights insights={insights} loading={loading} />
            </div>
          </div>

          <div className="mb-6 md:mb-8">
            <QuickActions />
          </div>

          <div>
            <RecentTradesTable
              trades={recentTrades}
              loading={loading}
              onViewAll={handleViewAllTrades}
            />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
