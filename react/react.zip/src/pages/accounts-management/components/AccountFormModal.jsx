import React, { useState, useEffect } from 'react';

import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Select from '../../../components/ui/Select';

const AccountFormModal = ({ isOpen, onClose, onSubmit, account, mode }) => {
  const [formData, setFormData] = useState({
    name: '',
    broker: '',
    type: '',
    balance: '',
    status: 'active',
    notes: ''
  });

  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (account && mode === 'edit') {
      setFormData({
        name: account?.name || '',
        broker: account?.broker || '',
        type: account?.type || '',
        balance: account?.balance?.toString() || '',
        status: account?.status || 'active',
        notes: account?.notes || ''
      });
    } else {
      setFormData({
        name: '',
        broker: '',
        type: '',
        balance: '',
        status: 'active',
        notes: ''
      });
    }
    setErrors({});
  }, [account, mode, isOpen]);

  const brokerOptions = [
    { value: 'interactive-brokers', label: 'Interactive Brokers' },
    { value: 'td-ameritrade', label: 'TD Ameritrade' },
    { value: 'etrade', label: 'E*TRADE' },
    { value: 'robinhood', label: 'Robinhood' },
    { value: 'charles-schwab', label: 'Charles Schwab' },
    { value: 'fidelity', label: 'Fidelity' },
    { value: 'webull', label: 'Webull' },
    { value: 'other', label: 'Other' }
  ];

  const typeOptions = [
    { value: 'cash', label: 'Cash Account' },
    { value: 'margin', label: 'Margin Account' },
    { value: 'options', label: 'Options Account' },
    { value: 'futures', label: 'Futures Account' }
  ];

  const statusOptions = [
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' }
  ];

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.name?.trim()) {
      newErrors.name = 'Account name is required';
    }

    if (!formData?.broker) {
      newErrors.broker = 'Broker selection is required';
    }

    if (!formData?.type) {
      newErrors.type = 'Account type is required';
    }

    if (!formData?.balance?.trim()) {
      newErrors.balance = 'Initial balance is required';
    } else if (isNaN(parseFloat(formData?.balance)) || parseFloat(formData?.balance) < 0) {
      newErrors.balance = 'Please enter a valid positive number';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);

    const submitData = {
      ...formData,
      balance: parseFloat(formData?.balance),
      lastActivity: new Date()?.toISOString()
    };

    if (mode === 'edit' && account) {
      submitData.id = account?.id;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    onSubmit(submitData);
    setIsSubmitting(false);
  };

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors?.[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm">
      <div className="bg-card border border-border rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-card border-b border-border px-4 md:px-6 py-4 flex items-center justify-between">
          <h2 className="text-lg md:text-xl font-semibold text-foreground">
            {mode === 'edit' ? 'Edit Account' : 'Add New Account'}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            iconName="X"
            iconSize={20}
            disabled={isSubmitting}
          />
        </div>

        <form onSubmit={handleSubmit} className="p-4 md:p-6 space-y-4 md:space-y-6">
          <Input
            label="Account Name"
            type="text"
            placeholder="e.g., Main Trading Account"
            value={formData?.name}
            onChange={(e) => handleChange('name', e?.target?.value)}
            error={errors?.name}
            required
            disabled={isSubmitting}
          />

          <Select
            label="Broker"
            options={brokerOptions}
            value={formData?.broker}
            onChange={(value) => handleChange('broker', value)}
            placeholder="Select your broker"
            error={errors?.broker}
            required
            searchable
            disabled={isSubmitting}
          />

          <Select
            label="Account Type"
            options={typeOptions}
            value={formData?.type}
            onChange={(value) => handleChange('type', value)}
            placeholder="Select account type"
            error={errors?.type}
            required
            disabled={isSubmitting}
          />

          <Input
            label="Initial Balance"
            type="number"
            placeholder="0.00"
            value={formData?.balance}
            onChange={(e) => handleChange('balance', e?.target?.value)}
            error={errors?.balance}
            required
            disabled={isSubmitting}
            description="Enter the starting balance for this account"
          />

          <Select
            label="Status"
            options={statusOptions}
            value={formData?.status}
            onChange={(value) => handleChange('status', value)}
            disabled={isSubmitting}
          />

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Notes <span className="text-muted-foreground">(Optional)</span>
            </label>
            <textarea
              value={formData?.notes}
              onChange={(e) => handleChange('notes', e?.target?.value)}
              placeholder="Add any additional notes about this account..."
              rows={4}
              disabled={isSubmitting}
              className="w-full px-3 py-2 bg-background border border-input rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed resize-none"
            />
          </div>

          <div className="flex flex-col-reverse sm:flex-row gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={isSubmitting}
              fullWidth
              className="sm:flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="default"
              loading={isSubmitting}
              fullWidth
              className="sm:flex-1"
            >
              {mode === 'edit' ? 'Update Account' : 'Create Account'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AccountFormModal;