import React from 'react';
import Icon from '../../../components/AppIcon';
import Select from '../../../components/ui/Select';

const SearchFilterBar = ({ 
  searchQuery, 
  onSearchChange, 
  filterBroker, 
  onBrokerChange,
  filterType,
  onTypeChange,
  filterStatus,
  onStatusChange 
}) => {
  const brokerOptions = [
    { value: 'all', label: 'All Brokers' },
    { value: 'interactive-brokers', label: 'Interactive Brokers' },
    { value: 'td-ameritrade', label: 'TD Ameritrade' },
    { value: 'etrade', label: 'E*TRADE' },
    { value: 'robinhood', label: 'Robinhood' },
    { value: 'charles-schwab', label: 'Charles Schwab' },
    { value: 'fidelity', label: 'Fidelity' },
    { value: 'webull', label: 'Webull' },
    { value: 'other', label: 'Other' }
  ];

  const typeOptions = [
    { value: 'all', label: 'All Types' },
    { value: 'cash', label: 'Cash Account' },
    { value: 'margin', label: 'Margin Account' },
    { value: 'options', label: 'Options Account' },
    { value: 'futures', label: 'Futures Account' }
  ];

  const statusOptions = [
    { value: 'all', label: 'All Status' },
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' }
  ];

  return (
    <div className="bg-card border border-border rounded-lg p-4 md:p-6 space-y-4">
      <div className="relative">
        <Icon 
          name="Search" 
          size={20} 
          className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" 
        />
        <input
          type="text"
          placeholder="Search accounts by name..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e?.target?.value)}
          className="w-full pl-10 pr-4 py-2.5 bg-background border border-input rounded-lg text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2"
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Select
          options={brokerOptions}
          value={filterBroker}
          onChange={onBrokerChange}
          placeholder="Filter by broker"
        />

        <Select
          options={typeOptions}
          value={filterType}
          onChange={onTypeChange}
          placeholder="Filter by type"
        />

        <Select
          options={statusOptions}
          value={filterStatus}
          onChange={onStatusChange}
          placeholder="Filter by status"
        />
      </div>
    </div>
  );
};

export default SearchFilterBar;