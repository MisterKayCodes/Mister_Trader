import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const AccountCard = ({ account, onEdit, onDelete, onSelect, isSelected }) => {
  const getStatusColor = (status) => {
    return status === 'active' ?'bg-success/10 text-success border-success/20' :'bg-muted text-muted-foreground border-border';
  };

  const getTypeIcon = (type) => {
    const icons = {
      'cash': 'Wallet',
      'margin': 'TrendingUp',
      'options': 'Target',
      'futures': 'LineChart'
    };
    return icons?.[type?.toLowerCase()] || 'Wallet';
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 2
    })?.format(amount);
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric'
    });
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 md:p-6 hover:shadow-md transition-smooth">
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-start gap-3 flex-1 min-w-0">
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Icon name={getTypeIcon(account?.type)} size={20} className="text-primary" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base md:text-lg font-semibold text-foreground mb-1 truncate">
              {account?.name}
            </h3>
            <p className="text-sm text-muted-foreground truncate">{account?.broker}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0 ml-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onEdit(account)}
            iconName="Edit2"
            iconSize={18}
            className="hover:bg-muted"
          />
          <Button
            variant="ghost"
            size="icon"
            onClick={() => onDelete(account)}
            iconName="Trash2"
            iconSize={18}
            className="hover:bg-destructive/10 hover:text-destructive"
          />
        </div>
      </div>
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Account Type</span>
          <span className="text-sm font-medium text-foreground capitalize">{account?.type}</span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Current Balance</span>
          <span className="text-base md:text-lg font-semibold text-foreground">
            {formatCurrency(account?.balance)}
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-muted-foreground">Status</span>
          <span className={`text-xs font-medium px-3 py-1 rounded-full border ${getStatusColor(account?.status)}`}>
            {account?.status === 'active' ? 'Active' : 'Inactive'}
          </span>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-border">
          <span className="text-xs text-muted-foreground">Last Activity</span>
          <span className="text-xs text-muted-foreground">{formatDate(account?.lastActivity)}</span>
        </div>
      </div>
      {account?.notes && (
        <div className="mt-4 pt-4 border-t border-border">
          <p className="text-sm text-muted-foreground line-clamp-2">{account?.notes}</p>
        </div>
      )}
    </div>
  );
};

export default AccountCard;