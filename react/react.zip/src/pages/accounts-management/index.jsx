import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import AuthenticatedHeader from '../../components/layout/AuthenticatedHeader';
import PrimaryNavigation from '../../components/layout/PrimaryNavigation';
import AccountContextBar from '../../components/layout/AccountContextBar';
import Button from '../../components/ui/Button';
import AccountCard from './components/AccountCard';
import AccountFormModal from './components/AccountFormModal';
import DeleteConfirmModal from './components/DeleteConfirmModal';
import SearchFilterBar from './components/SearchFilterBar';
import EmptyState from './components/EmptyState';

const AccountsManagement = () => {
  const [accounts, setAccounts] = useState([]);
  const [filteredAccounts, setFilteredAccounts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterBroker, setFilterBroker] = useState('all');
  const [filterType, setFilterType] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedAccount, setSelectedAccount] = useState(null);
  const [formMode, setFormMode] = useState('create');
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    fetchAccounts();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [accounts, searchQuery, filterBroker, filterType, filterStatus]);

  const fetchAccounts = async () => {
    setIsLoading(true);
    await new Promise(resolve => setTimeout(resolve, 800));

    const mockAccounts = [
      {
        id: 'acc-001',
        name: 'Main Trading Account',
        broker: 'Interactive Brokers',
        type: 'margin',
        balance: 125450.00,
        status: 'active',
        lastActivity: '2026-01-14T10:30:00Z',
        notes: 'Primary account for day trading and swing positions. Focus on tech stocks and options strategies.'
      },
      {
        id: 'acc-002',
        name: 'Day Trading Account',
        broker: 'TD Ameritrade',
        type: 'cash',
        balance: 48230.00,
        status: 'active',
        lastActivity: '2026-01-13T15:45:00Z',
        notes: 'Dedicated account for intraday scalping strategies with strict risk management rules.'
      },
      {
        id: 'acc-003',
        name: 'Swing Trading Account',
        broker: 'E*TRADE',
        type: 'margin',
        balance: 87650.00,
        status: 'active',
        lastActivity: '2026-01-12T09:20:00Z',
        notes: 'Medium-term positions held for 3-10 days. Focus on momentum and breakout patterns.'
      },
      {
        id: 'acc-004',
        name: 'Options Account',
        broker: 'Robinhood',
        type: 'options',
        balance: 22100.00,
        status: 'active',
        lastActivity: '2026-01-11T14:15:00Z',
        notes: 'Specialized account for options trading strategies including spreads and iron condors.'
      },
      {
        id: 'acc-005',
        name: 'Retirement IRA',
        broker: 'Charles Schwab',
        type: 'cash',
        balance: 156780.00,
        status: 'inactive',
        lastActivity: '2025-12-28T11:00:00Z',
        notes: 'Long-term retirement account with buy-and-hold strategy. Quarterly rebalancing only.'
      },
      {
        id: 'acc-006',
        name: 'Futures Trading',
        broker: 'Interactive Brokers',
        type: 'futures',
        balance: 65400.00,
        status: 'active',
        lastActivity: '2026-01-14T08:45:00Z',
        notes: 'Commodity futures and index futures trading. High leverage with tight stop losses.'
      }
    ];

    setAccounts(mockAccounts);
    setIsLoading(false);
  };

  const applyFilters = () => {
    let filtered = [...accounts];

    if (searchQuery?.trim()) {
      filtered = filtered?.filter(account =>
        account?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
        account?.broker?.toLowerCase()?.includes(searchQuery?.toLowerCase())
      );
    }

    if (filterBroker !== 'all') {
      filtered = filtered?.filter(account =>
        account?.broker?.toLowerCase()?.replace(/\s+/g, '-')?.replace(/\*/g, '') === filterBroker
      );
    }

    if (filterType !== 'all') {
      filtered = filtered?.filter(account => account?.type === filterType);
    }

    if (filterStatus !== 'all') {
      filtered = filtered?.filter(account => account?.status === filterStatus);
    }

    setFilteredAccounts(filtered);
  };

  const handleAddAccount = () => {
    setFormMode('create');
    setSelectedAccount(null);
    setIsFormModalOpen(true);
  };

  const handleEditAccount = (account) => {
    setFormMode('edit');
    setSelectedAccount(account);
    setIsFormModalOpen(true);
  };

  const handleDeleteAccount = (account) => {
    setSelectedAccount(account);
    setIsDeleteModalOpen(true);
  };

  const handleFormSubmit = async (formData) => {
    await new Promise(resolve => setTimeout(resolve, 500));

    if (formMode === 'create') {
      const newAccount = {
        ...formData,
        id: `acc-${Date.now()}`,
        lastActivity: new Date()?.toISOString()
      };
      setAccounts(prev => [newAccount, ...prev]);
    } else {
      setAccounts(prev =>
        prev?.map(acc => acc?.id === formData?.id ? { ...acc, ...formData } : acc)
      );
    }

    setIsFormModalOpen(false);
    setSelectedAccount(null);
  };

  const handleConfirmDelete = async () => {
    setIsDeleting(true);
    await new Promise(resolve => setTimeout(resolve, 500));

    setAccounts(prev => prev?.filter(acc => acc?.id !== selectedAccount?.id));
    setIsDeleting(false);
    setIsDeleteModalOpen(false);
    setSelectedAccount(null);
  };

  const hasActiveFilters = searchQuery?.trim() || filterBroker !== 'all' || filterType !== 'all' || filterStatus !== 'all';

  return (
    <>
      <Helmet>
        <title>Accounts Management - TradingJournal</title>
        <meta name="description" content="Manage your trading accounts, track balances, and organize your trading activities across multiple brokers and account types." />
      </Helmet>
      <AuthenticatedHeader />
      <PrimaryNavigation />
      <AccountContextBar />
      <main className="main-content with-account-context">
        <div className="main-content-container">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6 md:mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-foreground mb-2">
                Trading Accounts
              </h1>
              <p className="text-sm md:text-base text-muted-foreground">
                Manage and monitor all your trading accounts in one place
              </p>
            </div>
            <Button
              variant="default"
              onClick={handleAddAccount}
              iconName="Plus"
              iconPosition="left"
              className="sm:flex-shrink-0"
            >
              Add New Account
            </Button>
          </div>

          <SearchFilterBar
            searchQuery={searchQuery}
            onSearchChange={setSearchQuery}
            filterBroker={filterBroker}
            onBrokerChange={setFilterBroker}
            filterType={filterType}
            onTypeChange={setFilterType}
            filterStatus={filterStatus}
            onStatusChange={setFilterStatus}
          />

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mt-6">
              {[1, 2, 3, 4, 5, 6]?.map((i) => (
                <div key={i} className="bg-card border border-border rounded-lg p-6 animate-pulse">
                  <div className="flex items-start gap-3 mb-4">
                    <div className="w-12 h-12 bg-muted rounded-lg"></div>
                    <div className="flex-1">
                      <div className="h-5 bg-muted rounded w-3/4 mb-2"></div>
                      <div className="h-4 bg-muted rounded w-1/2"></div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded"></div>
                    <div className="h-4 bg-muted rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : filteredAccounts?.length === 0 ? (
            <div className="mt-6">
              <EmptyState onAddAccount={handleAddAccount} hasFilters={hasActiveFilters} />
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mt-6">
              {filteredAccounts?.map((account) => (
                <AccountCard
                  key={account?.id}
                  account={account}
                  onEdit={handleEditAccount}
                  onDelete={handleDeleteAccount}
                />
              ))}
            </div>
          )}

          {!isLoading && filteredAccounts?.length > 0 && (
            <div className="mt-8 p-4 bg-muted/50 rounded-lg border border-border">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="text-sm text-muted-foreground">
                  Showing <span className="font-medium text-foreground">{filteredAccounts?.length}</span> of{' '}
                  <span className="font-medium text-foreground">{accounts?.length}</span> accounts
                </div>
                <div className="text-sm text-muted-foreground">
                  Total Balance:{' '}
                  <span className="font-semibold text-foreground">
                    ${filteredAccounts?.reduce((sum, acc) => sum + acc?.balance, 0)?.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
      <AccountFormModal
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setSelectedAccount(null);
        }}
        onSubmit={handleFormSubmit}
        account={selectedAccount}
        mode={formMode}
      />
      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setSelectedAccount(null);
        }}
        onConfirm={handleConfirmDelete}
        account={selectedAccount}
        isDeleting={isDeleting}
      />
    </>
  );
};

export default AccountsManagement;