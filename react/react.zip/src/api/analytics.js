import axios from 'axios';

const API_BASE_URL = import.meta.env?.VITE_API_BASE_URL;

const getAuthHeaders = () => {
  const token = localStorage.getItem('trader_token');
  return {
    Authorization: `Bearer ${token}`
  };
};

const analyticsApi = {
  getStats: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/stats`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getSessions: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/sessions`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getStrategies: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/strategies`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getSymbols: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/symbols`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getDays: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/days`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getPsychology: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/psychology`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  getHourly: async () => {
    try {
      const response = await axios?.get(`${API_BASE_URL}/api/v1/analytics/hourly`, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  },

  refreshAnalytics: async () => {
    try {
      const response = await axios?.post(`${API_BASE_URL}/api/v1/analytics/refresh`, {}, {
        headers: getAuthHeaders()
      });
      return response?.data;
    } catch (error) {
      throw error;
    }
  }
};

export default analyticsApi;